# 06b_CodeLab_3

Grundlage des CodeLabs ist die Struktur App / Mitarbeiter 

Bauen Sie die Struktur wie folgt um:

Implementieren Sie eine Superklasse Mitarbeiter (MA etc.)sowie drei Subklassen, in die Sie das spezifische Verhalten (Advertising/Accounting/Production) auslagern.

Die Attribute in der Superklasse haben die Eigenschaft (Access modification) private

Erstellen Sie Sie von der entstandenen Struktur ein entsprechendes Klassendiagramm und speichern Sie dieses ab.

Extra:

Übergeben Sie den Instanzen accountant/worker/advertiser ein neues Argument
hiredYear , dass das Jahr der Einstellung des Mitarbeiters angibt.

Implementieren Sie eine geeignete Methode, die die Betriebszugehörigkeit in Jahren angibt.

Überlegen Sie eine geeignete Klasse, in der Sie das Feld hiredYear  & die dazugehörende Methode unterbringen können.

